function MyFloor(scene) {
 CGFobject.call(this,scene);

 this.MyUnitCubeQuad =new MyUnitCubeQuad(this.scene);
 this.MyUnitCubeQuad.initBuffers();
};

MyFloor.prototype = Object.create(CGFobject.prototype);
MyFloor.prototype.constructor = MyFloor;

MyFloor.prototype.display = function () {

    //TAMPO
    this.scene.pushMatrix();
    this.scene.scale(8,0.1,6);
    this.MyUnitCubeQuad.display();
    this.scene.popMatrix();

};